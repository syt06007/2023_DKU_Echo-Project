from scipy.spatial.transform import Rotation as R
import numpy as np



r = R.from_quat([-0.408716, 0.0432985, 0.888736, -0.203038])
#r = R.from_quat([0, 0, np.sin(np.pi/4), np.cos(np.pi/4)])

r = np.asarray(r.as_matrix()) # 쿼터니언을 rotation matrix로 변환
#print(r)

r_inversed = np.linalg.inv(r) #역행렬
#print("inversed r\n", r_inversed)
#print(np.dot(r,r_inversed)) #역행렬 검증

r_transposed = r_inversed.T # inverse/transpose : R^t
#print("R^t\n", r_transposed)

translation_vec = np.asarray([0.653312, 0.900915, 3.20866]) # translation vector : T
minus_Rt = -r_transposed
#print("-R^t\n", minus_Rt.shape)


transposed_trans = np.transpose(translation_vec[np.newaxis, :])
#print("translation\n", transposed_trans)
# Coordinates = -R^t dot T
coordinates =  np.dot(minus_Rt, transposed_trans)

print("coordinates: ", coordinates[0])



