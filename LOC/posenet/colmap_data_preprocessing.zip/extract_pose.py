filename = 'C:/Users/Admin/Desktop/sfm/VisualSFM_windows_cuda_64bit/dataset/gerrard-hall/sparse/images.txt'

f = open(filename, 'r')

pose = []

lines = f.readlines()
for line in lines:
    line = line.strip()  # 줄 끝의 줄 바꿈 문자를 제거한다.
    print(line)
    print(line.find('JPG'))
    if line.find('JPG') != -1 :
        pose.append(line)

print(pose)

filePath = 'C:/Users/Admin/Desktop/sfm/VisualSFM_windows_cuda_64bit/dataset/gerrard-hall/sparse/pose.txt'
with open(filePath, 'w') as new:
    new.write("IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME" + '\n\n')
    for lines in pose:
        new.write(lines + '\n')



f.close()



