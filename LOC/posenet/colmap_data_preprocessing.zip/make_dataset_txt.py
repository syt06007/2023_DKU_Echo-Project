from scipy.spatial.transform import Rotation as R
import numpy as np

filename = 'C:/Users/Admin/Desktop/sfm/VisualSFM_windows_cuda_64bit/dataset/gerrard-hall/sparse/pose.txt'

f = open(filename, 'r')

pose = []
temp = []
count = 0
lines = f.readlines()
for line in lines:
    count = count + 1
    line = line.strip()  # 줄 끝의 줄 바꿈 문자를 제거한다.
    #print(line)
    if line.find('JPG') != -1 : # JPG 있는 행에서
        temp.append(line.split(' '))
    #print(temp)
#  0,  1, 2,  3,  4,  5,  6,  7 ,    8,     9
# ID, QW, QX, QY, QZ, TX, TY, TZ, CAM_ID, FILE_NAME
# to
# FILE_NAME, X, Y, Z, W, P, Q, R

#print(pose)
#print(temp[0][5])

# TX, TY, TZ를 X, Y, Z로 변환해야함
# -R^t * T 가 X, Y, Z임

filePath = 'C:/Users/Admin/Desktop/sfm/VisualSFM_windows_cuda_64bit/dataset/gerrard-hall/sparse/dataset_xyz.txt'
with open(filePath, 'w') as new:
    new.write("ImageFile, Camera Position [X Y Z W P Q R]" + '\n\n')
    for i in range(0, count-2):
        quat = [temp[i][1], temp[i][2], temp[i][3], temp[i][4]] # QW,QX,QY,QZ를 불러옴
        translation_vec = np.asarray([float(temp[i][5]), float(temp[i][6]), float(temp[i][7])]) # translation vector : T
        transposed_trans = np.transpose(translation_vec[np.newaxis, :]) # 1,3으로 만듬

        r = R.from_quat(quat)
        r = np.asarray(r.as_matrix()) # 쿼터니언을 rotation matrix로 변환
        r_inversed = np.linalg.inv(r) #역행렬
        r_transposed = r_inversed.T # inverse/transpose : R^t
        minus_Rt = -r_transposed # -R^t
        print(minus_Rt, '\n', transposed_trans)
        coordinates =  np.dot(minus_Rt, transposed_trans) # x, y, z
        coordinates = list(map(str, coordinates))
        for j in range(0,3):
            coordinates[j] = coordinates[j].replace('[','')
            coordinates[j] = coordinates[j].replace(']','')
        
        new.write(temp[i][9]+' '+     # FILE_NAME
                  coordinates[0]+' '+ # X
                  coordinates[1]+' '+ # Y
                  coordinates[2]+' '+ # Z
                  temp[i][1]+' '+     # QW
                  temp[i][2]+' '+     # QX
                  temp[i][3]+' '+     # QY
                  temp[i][4]+' '      # QZ
                  +'\n'
                  )
        


f.close()
new.close()




