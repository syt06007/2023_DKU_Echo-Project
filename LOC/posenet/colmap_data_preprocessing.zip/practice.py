import numpy as np

# Define the matrices
matrix1 = np.array([[1, 2, 3],
                    [4, 5, 6],
                    [7, 8, 9]])

matrix2 = np.array([[1],
                    [2],
                    [3]])

# Perform the dot product
result = np.dot(matrix1, matrix2)

print(result)
print(matrix1.shape, matrix2.shape)